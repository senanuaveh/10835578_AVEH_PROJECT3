<?php
   // Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$recipeName = $ingredients = $preparation = "";
$recipeName_err = $ingredients_err = $preparation_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate recipeName
    if(empty(trim($_POST["recipeName"]))){
        $recipeName_err = "Please enter a recipe name.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE recipeName = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_recipeName);
            
            // Set parameters
            $param_recipeName = trim($_POST["recipeName"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $recipeName_err = "This recipe is already taken.";
                } else{
                    $recipeName = trim($_POST["recipeName"]);
                }
            } else{
                echo "Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate ingredients
    if(empty(trim($_POST["ingredients"]))){
        $ingredients_err = "Please enter ingredients.";     
    /*} elseif(strlen(trim($_POST["ingredients"])) < 6){
        $ingredients_err = "ingredients must have at least 6 characters.";
    } */else{
        $ingredients = trim($_POST["ingredients"]);
    }
    
    // Validate confirm ingredients
    if(empty(trim($_POST["preparation"]))){
        $preparation_err = "Please enter the preparation process";     
    } else{
        $preparation = trim($_POST["preparation"]);
        /*if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }*/
    }
    
    // Check input errors before inserting in database
    if(empty($recipeName_err) && empty($ingredients_err) && empty($preparation_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO recipes (recipeName, ingredients, preparation) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $param_recipeName, $param_ingredients, $param_preparation);
            
            // Set parameters
            $param_recipeName = $recipeName;
            $param_ingredients = $ingredients;
            $param_preparation = $preparation;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                echo "Success. Your recipe will be reviewed and if valid, will be added to the site \n Thank you";
                header("location:");
            } else{
                echo "Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
} 
?>
